/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.wsd;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlElement;

/**
 *
 * @author Ren
 */
public class Movie implements Serializable{
    
    
    private String id;
    
    private String name;
    
    private String director;
   
    private String description;
   
    private String duration;

    private String category;
    
    private String lister;
    
    private int year;

    public Movie() {
        super();
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getLister() {
        return lister;
    }

    public Movie(String id, String name, String director, String description, String duration, String category, String lister, int year) {
        this.id = id;
        this.name = name;
        this.director = director;
        this.description = description;
        this.duration = duration;
        this.category = category;
        this.lister = lister;
        this.year = year;
    }

    public void setLister(String lister) {
        this.lister = lister;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
    
    public String toString() {
        return "Book{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", director='" + director + '\'' +
                ", description='" + description + '\'' +
                ", duration='" + duration + '\'' +
                ", category='" + category + '\'' +
                ", lister='" + lister + '\'' +
                '}';
    }
    
}
