/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.wsd;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Ren
 */
public class Employees implements Serializable{
    
    private ArrayList<Employee> list = new ArrayList<Employee>();
    
    public ArrayList<Employee> getList() {
        return list;
    }
    
    public void addEmployee(Employee employee){
        list.add(employee);
    }
    
    public void removeSeller(Employee employee){
        list.remove(employee);
    }
    
    public Employee login(String email, String password){
        for(Employee employee : list) {
            if (employee.getEmail().equals(email)&&employee.getPassword().equals(password))
                return employee;
        }
        return null;
    }
    
}
