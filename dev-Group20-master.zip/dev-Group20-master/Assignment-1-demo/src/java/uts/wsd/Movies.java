/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.wsd;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Ren
 */
public class Movies implements Serializable{
    
    private ArrayList<Movie> list = new ArrayList<Movie>();

    public ArrayList<Movie> getList() {
        return list;
    }

    public void addBook(Movie movie) {
        list.add(movie);
    }


    public void removeBook(Movie movie) {
        list.remove(movie);
    }

    public Movie getMovie(String id) {
        for (Movie movie : list) {
            System.out.print(movie);
            if (movie.getId().equals(id)) {
                return movie;
            }
        }
        return null;
    }

    public List<Movie> getMyMovie(String lister) {
        ArrayList<Movie> movies = new ArrayList<>();
        for (Movie movie : list) {
            System.out.print(movie);
            if (movie.getLister().equals(lister)) {
                movies.add(movie);
            }
        }
        return movies;
    }
    
}
